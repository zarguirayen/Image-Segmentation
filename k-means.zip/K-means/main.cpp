#include <iostream>
#include <opencv2/opencv.hpp>
#include <filesystem>

using namespace std;
using namespace cv;
namespace fs = std::filesystem;

int main(int argc, char **argv) {
    if (argc < 2) {
        cerr << "Usage: " << argv[0] << " <image_input>" << endl;
        return -1;
    }

    // Charger l'image
    Mat orig = imread(argv[1]);
    if (orig.empty()) {
        cerr << "Erreur : Impossible de charger l'image " << argv[1] << endl;
        return -1;
    }

    // Convertir l'image en niveaux de gris
    Mat gray;
    cvtColor(orig, gray, COLOR_BGR2GRAY);

    // Appliquer un flou pour réduire le bruit
    Mat blurred;
    GaussianBlur(gray, blurred, Size(5, 5), 2.0);

    // Convertir l'image pour K-means (1 canal)
    Mat data;
    blurred.convertTo(data, CV_32F);
    data = data.reshape(1, data.total()); // (N, 1) pour les niveaux de gris

    // Appliquer K-means
    int K = 2; // Nombre de classes
    Mat labels, centers;
    kmeans(data, K, labels, TermCriteria(TermCriteria::EPS + TermCriteria::MAX_ITER, 10, 1.0), 3, KMEANS_PP_CENTERS, centers);

    // Reconstruire l'image segmentée (Niveaux de gris)
    Mat segmented = Mat::zeros(gray.size(), CV_8U);
    for (int i = 0; i < data.rows; i++) {
        int cluster_idx = labels.at<int>(i);
        segmented.at<uchar>(i / gray.cols, i % gray.cols) = (uchar)centers.at<float>(cluster_idx);
    }

    // Afficher les résultats
    imshow("Original", orig);
    imshow("Segmented (Grayscale)", segmented);
    waitKey(0);

    // Enregistrer l'image segmentée
    fs::path input_path(argv[1]);
    fs::path output_path = input_path.parent_path() / "segmented_result_gray.png";
    imwrite(output_path.string(), segmented);

    cout << "Image segmentée enregistrée dans : " << output_path.string() << endl;

    return 0;
}

