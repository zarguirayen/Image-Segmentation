#include <iostream>
#include <opencv2/opencv.hpp>
#include <cmath>

using namespace std;
using namespace cv;

// --- Classe pour le prétraitement de l'image ---
class ImageProcessor {
public:
    Mat preprocess(const Mat &image) {
        Mat gray, blurred, equalized;
        if (image.channels() == 3)
            cvtColor(image, gray, COLOR_BGR2GRAY);
        else
            gray = image.clone();
        GaussianBlur(gray, blurred, Size(5, 5), 1.0);
        equalizeHist(blurred, equalized);
        equalized.convertTo(equalized, CV_64F, 1.0 / 255.0);
        return equalized;
    }
};

// --- Classe pour la segmentation Chan-Vese ---
class ChanVeseSegmenter {
public:
    Mat initializePhi(const Mat &image);
    void segment(const Mat &image, Mat &phi);
    Mat getSegmentationMask(const Mat &phi);
};

void ChanVeseSegmenter::segment(const Mat &image, Mat &phi) {
    int rows = image.rows, cols = image.cols;
    for (int iter = 0; iter < 1000; iter++) {
        Mat mask_inside = (phi < 0);
        Mat mask_outside = (phi >= 0);
        double c_inside = mean(image, mask_inside)[0];
        double c_outside = mean(image, mask_outside)[0];
        double error = 0.0;
        for (int i = 1; i < rows - 1; i++) {
            for (int j = 1; j < cols - 1; j++) {
                double data_force = -pow(image.at<double>(i, j) - c_inside, 2) + pow(image.at<double>(i, j) - c_outside, 2);
                double dphi = 0.25 * data_force;
                phi.at<double>(i, j) += dphi;
                error += fabs(dphi);
            }
        }
        error /= (rows * cols);
        if (error < 1e-5) break;
    }
}

Mat ChanVeseSegmenter::getSegmentationMask(const Mat &phi) {
    Mat mask;
    threshold(phi, mask, 0, 255, THRESH_BINARY_INV);
    mask.convertTo(mask, CV_8U);
    return mask;
}

Mat ChanVeseSegmenter::initializePhi(const Mat &image) {
    Mat image8U;
    image.convertTo(image8U, CV_8U, 255.0);
    Mat thresh;
    threshold(image8U, thresh, 0, 255, THRESH_BINARY | THRESH_OTSU);
    Mat phi(image.size(), CV_64F);
    for (int i = 0; i < image.rows; i++) {
        for (int j = 0; j < image.cols; j++) {
            phi.at<double>(i, j) = (thresh.at<uchar>(i, j) == 0) ? -1.0 : 1.0;
        }
    }
    return phi;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        cerr << "Usage: " << argv[0] << " <image_input>" << endl;
        return -1;
    }
   
    Mat orig = imread(argv[1]);
    if (orig.empty()) {
        cerr << "Erreur : Impossible de charger l'image " << argv[1] << endl;
        return -1;
    }
   
    ImageProcessor processor;
    Mat image = processor.preprocess(orig);
    ChanVeseSegmenter segmenter;
    Mat phi = segmenter.initializePhi(image);
    segmenter.segment(image, phi);
    Mat mask = segmenter.getSegmentationMask(phi);
    imwrite("segmentation_binaire.png", mask);
    cout << "Segmentation binaire enregistrée sous : segmentation_binaire.png" << endl;
    return 0;
}
